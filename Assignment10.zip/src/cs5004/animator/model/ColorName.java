package cs5004.animator.model;

/**
 * Represent the colors name. This can be expand to store more colors and use to print out proper
 * color name instead of just rgb color code.
 */
public enum ColorName {



  BLACK,
  WHITE, RED, GREEN, BLUE;

}
